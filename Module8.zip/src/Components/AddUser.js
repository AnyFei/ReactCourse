import React, { useState } from 'react'
import Card from './Card'
import Button from '../UI/Button'
import classes from './AddUser.module.css'

const AddUser = () =>{

    const [enteredUsername, setEnteredUsername] = useState('');
    const [enteredAge, setenteredAge] = useState('');

    const usernameOnChangeHandler = event =>{
        setEnteredUsername(event.target.value);
    };
    const ageOnChangeHandler = event =>{
        setenteredAge(event.target.value);
    };

    const addUserHandler = (event) =>{
        event.preventDefault();
        setEnteredUsername('');
        setenteredAge('');
    };
    return(
        <Card className={classes.input}>
        <form onSubmit={addUserHandler}> 
            <label htmlFor='username'>Username</label>
            <input type='text' name='username' onChange={usernameOnChangeHandler}></input>
            <label htmlFor='age'>Name</label>
            <input type='number' name='age' onChange={ageOnChangeHandler}></input>
            <Button type='submit'>Add user</Button>
        </form>
        </Card>

    );
}

export default AddUser;
